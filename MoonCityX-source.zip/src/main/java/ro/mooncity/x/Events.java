package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;
import ro.mooncity.x.feat.*;

@Mod.EventBusSubscriber(modid = MoonX.ID)
public class Events {
    static int tick;
    /** Vehiculele incarcate (tinute la zi prin join/leave) - evita scanarea tuturor entitatilor. */
    public static final java.util.Set<Entity> VEHICLES = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<>());

    @SubscribeEvent
    public static void joined(EntityJoinLevelEvent e) {
        if (!e.getLevel().isClientSide && Util.isVehicle(e.getEntity())) VEHICLES.add(e.getEntity());
    }

    @SubscribeEvent
    public static void left(EntityLeaveLevelEvent e) {
        if (!e.getLevel().isClientSide) VEHICLES.remove(e.getEntity());
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        CompoundTag r = Db.touch(sp);
        if (!r.getBoolean("starter")) {
            r.putBoolean("starter", true);
            Util.give(sp, new ItemStack(Reg.PHONE.get()));
            Util.give(sp, Docs.card(sp.getUUID()));
        }
        Util.msg(sp, "§bBine ai venit pe MoonCity! ID-ul tău: §f" + r.getInt("id"));
        Bank.sync(sp.getUUID());
        Db.dirty();
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        tick++;
        try {
            if (tick % 10 == 0) Fuel.tick(s);
            if (tick % 20 == 0) Taxi.tick(s);
            if (tick % 100 == 0) speed(s);
            if (tick % 400 == 0) Garage.scan(s);
            if (tick % 200 == 0) Optimizer.scan(s);
            if (tick % 200 == 0) for (ServerPlayer p : s.getPlayerList().getPlayers()) Bank.sync(p.getUUID());
            if (tick % (Math.max(1, Cfg.I.paydayMinutes) * 1200) == 0) Jobs.payday(s);
            if (tick % 72000 == 0) City.hourly(s);
        } catch (Exception ex) {
            MoonX.LOG.error("Eroare in tick", ex);
        }
    }

    static void speed(MinecraftServer s) {
        for (Entity en : VEHICLES) if (en.isAlive() && !en.getPassengers().isEmpty()) Veh.applySpeed(en);
    }

    @SubscribeEvent
    public static void mount(EntityMountEvent e) {
        if (!e.isMounting() || e.getLevel().isClientSide) return;
        if (e.getEntityMounting() instanceof ServerPlayer sp && Util.isVehicle(e.getEntityBeingMounted())
            && Cfg.I.enforceLicense && !Docs.hasLicense(sp.getUUID()) && !Util.op(sp)) {
            e.setCanceled(true);
            Util.bar(sp, "§cNu ai permis de conducere! Mergi la Școala de șoferi.");
        }
    }

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (e.getPlayer() instanceof ServerPlayer sp) Jobs.onBreak(sp, e.getState());
    }

    @SubscribeEvent
    public static void fished(ItemFishedEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) Jobs.onFish(sp);
    }
}
