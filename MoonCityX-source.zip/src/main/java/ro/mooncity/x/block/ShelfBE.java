package ro.mooncity.x.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import ro.mooncity.x.Reg;

public class ShelfBE extends BlockEntity {
    public ItemStack shown = ItemStack.EMPTY;

    public ShelfBE(BlockPos pos, BlockState st) { super(Reg.SHELF_BE.get(), pos, st); }

    public void setShown(ItemStack s) {
        shown = s.copy();
        shown.setCount(1);
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.put("shown", shown.save(new CompoundTag()));
    }

    @Override
    public void load(CompoundTag t) {
        super.load(t);
        shown = ItemStack.of(t.getCompound("shown"));
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag t = new CompoundTag();
        saveAdditional(t);
        return t;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }
}
