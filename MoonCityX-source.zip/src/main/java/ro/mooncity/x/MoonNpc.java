package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import ro.mooncity.x.feat.Npcs;

/** NPC static (nu se misca, nu moare). Rolul decide meniul. Admin: shift+click cu un baston = sterge. */
public class MoonNpc extends PathfinderMob {
    static final EntityDataAccessor<String> ROLE = SynchedEntityData.defineId(MoonNpc.class, EntityDataSerializers.STRING);

    public MoonNpc(EntityType<? extends PathfinderMob> t, Level l) {
        super(t, l);
        setPersistenceRequired();
        setInvulnerable(true);
    }

    public static AttributeSupplier attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20).add(Attributes.MOVEMENT_SPEED, 0).build();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(ROLE, "seller");
    }

    public String role() { return entityData.get(ROLE); }

    public void setRole(String r) {
        entityData.set(ROLE, r);
        setCustomName(Component.literal(Npcs.title(r)));
        setCustomNameVisible(true);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Override
    public InteractionResult mobInteract(Player pl, InteractionHand h) {
        if (!level().isClientSide && pl instanceof ServerPlayer sp) {
            if (sp.isShiftKeyDown() && Util.op(sp) && sp.getItemInHand(h).is(net.minecraft.world.item.Items.STICK)) {
                discard();
                return InteractionResult.SUCCESS;
            }
            Npcs.open(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean hurt(DamageSource s, float a) { return s.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY) && super.hurt(s, a); }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putString("role", role());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.contains("role")) setRole(t.getString("role"));
    }
}
