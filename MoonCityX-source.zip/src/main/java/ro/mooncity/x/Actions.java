package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.feat.*;

/** Dispecer: clientul trimite "modul:actiune" + date. Fiecare modul valideaza pe server. */
public class Actions {
    public static void handle(ServerPlayer p, String act, CompoundTag d) {
        try {
            int i = act.indexOf(':');
            String m = i < 0 ? act : act.substring(0, i);
            String s = i < 0 ? "" : act.substring(i + 1);
            switch (m) {
                case "bank" -> Bank.act(p, s, d);
                case "docs" -> Docs.act(p, s, d);
                case "npc" -> Npcs.act(p, s, d);
                case "job" -> Jobs.act(p, s, d);
                case "shop" -> Shops.act(p, s, d);
                case "garage" -> Garage.act(p, s, d);
                case "fuel" -> Fuel.act(p, s, d);
                case "tune" -> Tuning.act(p, s, d);
                case "taxi" -> Taxi.act(p, s, d);
                case "mdt" -> Mdt.act(p, s, d);
                case "school" -> School.act(p, s, d);
                case "casino" -> Casino.act(p, s, d);
                case "ctr" -> Contracts.act(p, s, d);
                case "phone" -> Phone.act(p, s, d);
                case "news", "soc", "rep", "evt" -> Social.act(m, p, s, d);
                case "city", "terr", "pol", "biz", "prop", "bus", "med" -> City.act(m, p, s, d);
                default -> Util.msg(p, "§cAcțiune necunoscută: " + act);
            }
        } catch (Exception e) {
            MoonX.LOG.error("Eroare la actiunea " + act, e);
            Util.msg(p, "§cEroare internă la acțiunea " + act + " (vezi consola serverului).");
        }
    }
}
