package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.UUID;

/** Baza de date a serverului (un singur SavedData cu sectiuni NBT). */
public class Db extends SavedData {
    public CompoundTag root = new CompoundTag();

    public static Db get() {
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        return s.overworld().getDataStorage().computeIfAbsent(Db::load, Db::new, "mooncityx");
    }

    public static Db load(CompoundTag t) {
        Db d = new Db();
        d.root = t.getCompound("r");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.put("r", root);
        return t;
    }

    /** Sectiune de top-level (creata la nevoie). Modificarile se salveaza automat. */
    public static CompoundTag sec(String n) {
        Db d = get();
        if (!d.root.contains(n, Tag.TAG_COMPOUND)) d.root.put(n, new CompoundTag());
        d.setDirty();
        return d.root.getCompound(n);
    }

    public static void dirty() { get().setDirty(); }

    public static CompoundTag sub(CompoundTag t, String k) {
        if (!t.contains(k, Tag.TAG_COMPOUND)) t.put(k, new CompoundTag());
        return t.getCompound(k);
    }

    public static ListTag list(CompoundTag t, String k) {
        if (!t.contains(k, Tag.TAG_LIST)) t.put(k, new ListTag());
        return t.getList(k, Tag.TAG_COMPOUND);
    }

    public static ListTag slist(CompoundTag t, String k) {
        if (!t.contains(k, Tag.TAG_LIST)) t.put(k, new ListTag());
        return t.getList(k, Tag.TAG_STRING);
    }

    public static void addStr(ListTag l, String s, int max) {
        l.add(StringTag.valueOf(s));
        while (l.size() > max) l.remove(0);
    }

    // ---------- jucatori ----------
    public static CompoundTag p(UUID id) {
        CompoundTag all = sec("players");
        String k = id.toString();
        if (!all.contains(k, Tag.TAG_COMPOUND)) all.put(k, new CompoundTag());
        dirty();
        return all.getCompound(k);
    }

    public static boolean known(UUID id) { return sec("players").contains(id.toString(), Tag.TAG_COMPOUND); }

    /** Apelat la login: creeaza contul si da ID-ul automat (urmatorul liber). */
    public static CompoundTag touch(ServerPlayer sp) {
        CompoundTag r = p(sp.getUUID());
        r.putString("name", sp.getGameProfile().getName());
        if (!r.contains("id")) {
            CompoundTag meta = sec("meta");
            int next = meta.getInt("nextId") + 1;
            meta.putInt("nextId", next);
            r.putInt("id", next);
            r.putLong("bank", 500);
            Bank.log(sp.getUUID(), "+500 RON  Bonus de bun venit");
        }
        return r;
    }

    public static int id(UUID u) { return p(u).getInt("id"); }

    public static String name(UUID u) {
        String n = p(u).getString("name");
        return n.isEmpty() ? "necunoscut" : n;
    }

    public static UUID byId(int id) {
        CompoundTag all = sec("players");
        for (String k : all.getAllKeys()) if (all.getCompound(k).getInt("id") == id) return UUID.fromString(k);
        return null;
    }

    /** Cauta dupa ID (numar) sau nume (partial, fara majuscule). */
    public static UUID find(String q) {
        q = q.trim();
        if (q.isEmpty()) return null;
        try { return byId(Integer.parseInt(q.replace("#", ""))); } catch (NumberFormatException ignored) { }
        CompoundTag all = sec("players");
        UUID part = null;
        for (String k : all.getAllKeys()) {
            String n = all.getCompound(k).getString("name");
            if (n.equalsIgnoreCase(q)) return UUID.fromString(k);
            if (part == null && n.toLowerCase().contains(q.toLowerCase())) part = UUID.fromString(k);
        }
        return part;
    }
}
