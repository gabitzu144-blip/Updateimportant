package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/** Doua pachete: S2C (server -> client: meniu/ecran/sync) si C2S (client -> server: actiune). */
public class Net {
    static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(new ResourceLocation(MoonX.ID, "main"), () -> V, V::equals, V::equals);

    public record S2C(String kind, CompoundTag tag) { }
    public record C2S(String act, CompoundTag tag) { }

    public static void init() {
        int i = 0;
        CH.registerMessage(i++, S2C.class,
            (m, b) -> { b.writeUtf(m.kind()); b.writeNbt(m.tag()); },
            b -> { String k = b.readUtf(); CompoundTag t = b.readNbt(); return new S2C(k, t == null ? new CompoundTag() : t); },
            Net::handleS2C);
        CH.registerMessage(i++, C2S.class,
            (m, b) -> { b.writeUtf(m.act()); b.writeNbt(m.tag()); },
            b -> { String k = b.readUtf(); CompoundTag t = b.readNbt(); return new C2S(k, t == null ? new CompoundTag() : t); },
            Net::handleC2S);
    }

    static void handleS2C(S2C m, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.x.client.ClientHooks.recv(m.kind(), m.tag())));
        c.get().setPacketHandled(true);
    }

    static void handleC2S(C2S m, Supplier<NetworkEvent.Context> c) {
        ServerPlayer p = c.get().getSender();
        c.get().enqueueWork(() -> { if (p != null) Actions.handle(p, m.act(), m.tag()); });
        c.get().setPacketHandled(true);
    }

    public static void to(ServerPlayer p, String kind, CompoundTag tag) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new S2C(kind, tag));
    }

    public static void toServer(String act, CompoundTag tag) {
        CH.sendToServer(new C2S(act, tag));
    }

    public static void close(ServerPlayer p) { to(p, "close", new CompoundTag()); }
}
