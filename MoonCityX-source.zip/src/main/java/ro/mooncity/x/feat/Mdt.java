package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/** MDT (tableta politiei): cautare cetateni, amenzi, wanted, permise, vehicule, curse taxi. */
public class Mdt {
    static boolean access(ServerPlayer p) { return Jobs.is(p.getUUID(), "police") || Util.op(p); }

    public static void open(ServerPlayer p) {
        if (!access(p)) { Util.msg(p, "§cMDT: acces permis doar poliției."); return; }
        Ui ui = Ui.of("§9MDT — Poliția MoonCity").line("§7Agent: §f" + p.getName().getString() + " §7(ID " + Db.id(p.getUUID()) + ")")
            .in("q", "Caută cetățean (ID / nume)", "").btn("Caută", "mdt:find")
            .btn("Persoane căutate (wanted)", "mdt:wanted").btn("Curse taxi înregistrate", "mdt:rides").btn("Amenzi recente", "mdt:fines");
        ui.send(p);
    }

    public static void setWanted(UUID u, boolean w, String why) {
        CompoundTag r = Db.p(u);
        r.putBoolean("wanted", w);
        r.putString("wantedWhy", w ? why : "");
        Db.dirty();
        if (w) for (ServerPlayer sp : ro.mooncity.x.Util.online(u) == null ? java.util.List.<ServerPlayer>of() : java.util.List.of(Util.online(u))) { /* tinta nu e anuntata */ }
        if (w) {
            net.minecraft.server.MinecraftServer s = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
            if (s != null) for (ServerPlayer c : s.getPlayerList().getPlayers()) if (Jobs.is(c.getUUID(), "police")) Util.msg(c, "§9[MDT] §cSuspect căutat: " + Db.name(u) + " (ID " + Db.id(u) + ") — " + why);
        }
    }

    /** Adauga amenda si incearca sa o incaseze imediat. */
    public static void fine(UUID t, long amt, String why, String by) {
        CompoundTag f = new CompoundTag();
        f.putLong("amt", amt);
        f.putString("why", why);
        f.putString("by", by);
        f.putString("at", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm")));
        boolean paid = Bank.take(t, amt, "Amendă: " + why);
        f.putBoolean("paid", paid);
        if (paid) City.budget(amt, "Amendă");
        Db.list(Db.p(t), "fines").add(f);
        ListTag g = Db.list(Db.sec("mdt"), "all");
        CompoundTag g2 = f.copy();
        g2.putString("who", t.toString());
        g.add(g2);
        while (g.size() > 100) g.remove(0);
        ServerPlayer tp = Util.online(t);
        if (tp != null) Util.msg(tp, "§c[Amendă] " + Util.fmt(amt) + " — " + why + (paid ? " (achitată automat)" : " (neachitată – plătește la Primărie)"));
        Db.dirty();
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        if (!access(p)) return;
        switch (s) {
            case "main" -> open(p);
            case "find" -> {
                UUID t = Db.find(Util.str(d, "q"));
                if (t == null) { Util.msg(p, "§cNu am găsit cetățeanul."); open(p); } else profile(p, t);
            }
            case "prof" -> profile(p, UUID.fromString(Util.str(d, "t")));
            case "fine" -> {
                UUID t = UUID.fromString(Util.str(d, "t"));
                long a = Util.num(d, "amt");
                if (a > 0 && a <= 100000) fine(t, a, Util.str(d, "why").isEmpty() ? "Contravenție" : Util.str(d, "why"), p.getName().getString());
                profile(p, t);
            }
            case "wanted" -> {
                if (d.contains("t")) {
                    UUID t = UUID.fromString(Util.str(d, "t"));
                    setWanted(t, !Db.p(t).getBoolean("wanted"), Util.str(d, "why").isEmpty() ? "Căutat de poliție" : Util.str(d, "why"));
                    profile(p, t);
                } else {
                    Ui ui = Ui.of("§9Persoane căutate");
                    CompoundTag all = Db.sec("players");
                    for (String k : all.getAllKeys()) {
                        CompoundTag r = all.getCompound(k);
                        if (r.getBoolean("wanted")) ui.btn(r.getString("name") + " (ID " + r.getInt("id") + ") – " + r.getString("wantedWhy"), "mdt:prof", "t", k);
                    }
                    ui.btn("« MDT", "mdt:main").send(p);
                }
            }
            case "revoke" -> {
                UUID t = UUID.fromString(Util.str(d, "t"));
                Db.p(t).putBoolean("lic", false);
                Db.p(t).putBoolean("theory", false);
                Util.msg(p, "§aPermis retras.");
                ServerPlayer tp = Util.online(t);
                if (tp != null) Util.msg(tp, "§c[MDT] Permisul tău a fost retras.");
                profile(p, t);
            }
            case "note" -> {
                UUID t = UUID.fromString(Util.str(d, "t"));
                if (!Util.str(d, "n").isEmpty()) Db.addStr(Db.slist(Db.p(t), "notes"), LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM HH:mm")) + " " + p.getName().getString() + ": " + Util.str(d, "n"), 30);
                profile(p, t);
            }
            case "rides" -> Taxi.ridesMenu(p);
            case "fines" -> {
                Ui ui = Ui.of("§9Amenzi recente");
                ListTag g = Db.list(Db.sec("mdt"), "all");
                for (int i = g.size() - 1; i >= 0 && i >= g.size() - 25; i--) {
                    CompoundTag f = g.getCompound(i);
                    ui.line("§f" + f.getString("at") + " §7" + Db.name(UUID.fromString(f.getString("who"))) + " • " + Util.fmt(f.getLong("amt")) + " • " + f.getString("why") + (f.getBoolean("paid") ? " §a✔" : " §c✘"));
                }
                ui.btn("« MDT", "mdt:main").send(p);
            }
            default -> open(p);
        }
    }

    static void profile(ServerPlayer p, UUID t) {
        CompoundTag r = Db.p(t);
        CompoundTag d = new CompoundTag();
        d.putString("t", t.toString());
        Ui ui = Ui.of("§9Dosar: " + r.getString("name") + " (ID " + r.getInt("id") + ")")
            .line("§7Job: §f" + Jobs.name(r.getString("job")) + "   §7Reputație: §f" + r.getInt("rep"))
            .line("§7Permis: " + (r.getBoolean("lic") ? "§aValid" : "§cNu are") + "   §7Buletin: " + (r.contains("idDate") ? "§a" + r.getString("idDate") : "§cNu are"))
            .line("§7Căutat: " + (r.getBoolean("wanted") ? "§cDA – " + r.getString("wantedWhy") : "§aNu"))
            .line("§7IBAN: §f" + Bank.iban(t) + "   §7Garaj: §f" + Db.list(r, "garage").size() + " vehicule");
        ListTag g = Db.list(r, "garage");
        for (int i = 0; i < g.size(); i++) ui.line("  §8• " + g.getCompound(i).getString("name"));
        ui.line("§eAmenzi:");
        ListTag f = Db.list(r, "fines");
        for (int i = f.size() - 1; i >= 0 && i >= f.size() - 6; i--) {
            CompoundTag x = f.getCompound(i);
            ui.line("§f" + x.getString("at") + " " + Util.fmt(x.getLong("amt")) + " " + x.getString("why") + (x.getBoolean("paid") ? " §a✔" : " §c✘"));
        }
        ListTag n = Db.slist(r, "notes");
        ui.line("§eNote:");
        for (int i = n.size() - 1; i >= 0 && i >= n.size() - 5; i--) ui.line("§7" + n.getString(i));
        ui.in("amt", "Amendă (RON)", "500").in("why", "Motiv", "").btn("Dă amendă", "mdt:fine", d)
            .btn(r.getBoolean("wanted") ? "Scoate din căutare" : "Declară căutat", "mdt:wanted", d)
            .btn("Retrage permisul", "mdt:revoke", d)
            .in("n", "Notă nouă", "").btn("Adaugă notă", "mdt:note", d).btn("« MDT", "mdt:main").send(p);
    }
}
