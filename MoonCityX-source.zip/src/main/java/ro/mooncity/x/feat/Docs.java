package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;
import ro.mooncity.x.item.DocItem;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.UUID;

/** Buletin, permis, card bancar (iteme cu date) + afisarea lor ca acte romanesti. */
public class Docs {
    static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    static ItemStack base(Item it, UUID u) {
        ItemStack s = new ItemStack(it);
        CompoundTag t = s.getOrCreateTag();
        CompoundTag r = Db.p(u);
        t.putString("name", Db.name(u));
        t.putInt("pid", r.getInt("id"));
        t.putString("uuid", u.toString());
        return s;
    }

    static String cnp(UUID u, String born, boolean male) {
        Random rnd = new Random(u.getLeastSignificantBits() ^ u.getMostSignificantBits());
        int yy = Integer.parseInt(born.substring(8, 10));
        int sx = Integer.parseInt(born.substring(6, 10)) >= 2000 ? (male ? 5 : 6) : (male ? 1 : 2);
        String body = sx + String.format("%02d", yy) + born.substring(3, 5) + born.substring(0, 2)
            + String.format("%02d", 1 + rnd.nextInt(40)) + String.format("%03d", rnd.nextInt(999));
        int[] w = {2, 7, 9, 1, 4, 6, 3, 5, 8, 2, 7, 9};
        int sum = 0;
        for (int i = 0; i < 12; i++) sum += (body.charAt(i) - '0') * w[i];
        int c = sum % 11;
        return body + (c == 10 ? 1 : c);
    }

    public static ItemStack idCard(UUID u) {
        ItemStack s = base(Reg.ID_CARD.get(), u);
        CompoundTag t = s.getTag();
        Random rnd = new Random(u.getLeastSignificantBits());
        boolean male = (rnd.nextInt(2) == 0);
        LocalDate b = LocalDate.of(1980 + rnd.nextInt(26), 1 + rnd.nextInt(12), 1 + rnd.nextInt(28));
        String born = b.format(DF);
        t.putString("born", born);
        t.putBoolean("male", male);
        t.putString("cnp", cnp(u, born, male));
        t.putString("issued", LocalDate.now().format(DF));
        t.putString("exp", LocalDate.now().plusYears(10).format(DF));
        t.putString("addr", "Mun. MoonCity, Str. Lunii nr. " + (1 + rnd.nextInt(120)));
        t.putString("series", "MC " + String.format("%06d", rnd.nextInt(999999)));
        return s;
    }

    public static ItemStack license(UUID u) {
        ItemStack s = base(Reg.LICENSE.get(), u);
        CompoundTag t = s.getTag();
        t.putString("issued", LocalDate.now().format(DF));
        t.putString("exp", LocalDate.now().plusYears(10).format(DF));
        t.putString("cat", "B");
        t.putString("born", idCard(u).getTag().getString("born"));
        return s;
    }

    public static ItemStack card(UUID u) {
        ItemStack s = base(Reg.BANK_CARD.get(), u);
        s.getTag().putString("iban", Bank.iban(u));
        return s;
    }

    public static void show(ServerPlayer viewer, ItemStack st) {
        if (!(st.getItem() instanceof DocItem di)) return;
        CompoundTag t = st.getTag() == null ? new CompoundTag() : st.getTag().copy();
        Net.to(viewer, di.kind, t);
    }

    public static boolean hasLicense(UUID u) { return Db.p(u).getBoolean("lic"); }

    public static void grantLicense(ServerPlayer p) {
        Db.p(p.getUUID()).putBoolean("lic", true);
        Db.p(p.getUUID()).putInt("points", 15);
        Util.give(p, license(p.getUUID()));
        Util.msg(p, "§a§lAi primit permisul de conducere (categoria B)!");
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        if (s.equals("buyid")) {
            long fee = Db.p(u).contains("idDate") ? Cfg.I.idCardPrice / 2 : Cfg.I.idCardPrice;
            if (!Bank.take(u, fee, "Taxă buletin (Primărie)")) { Util.msg(p, "§cFonduri insuficiente (" + Util.fmt(fee) + ")."); }
            else {
                Db.p(u).putString("idDate", LocalDate.now().format(DF));
                City.budget(fee, "Taxă buletin");
                Util.give(p, idCard(u));
                Util.msg(p, "§aAi primit buletinul. Click dreapta = îl vezi, click pe un jucător = i-l arăți.");
            }
        } else if (s.equals("dupl")) {
            if (!Db.p(u).getBoolean("lic")) { Util.msg(p, "§cNu ai permis."); return; }
            if (Bank.take(u, Cfg.I.licensePrice / 4, "Duplicat permis")) { Util.give(p, license(u)); }
            else Util.msg(p, "§cFonduri insuficiente.");
        }
        City.cityMenu(p);
    }
}
