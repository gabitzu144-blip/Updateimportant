package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.util.Random;
import java.util.UUID;

/** Sloturi + ruleta rosu/negru. Pariu max din Cfg.maxBet. */
public class Casino {
    static final Random R = new Random();
    static final String[] SYM = {"A", "B", "C", "7", "$"};

    public static void menu(ServerPlayer p) {
        Ui.of("§cCazino MoonCity")
            .line("§7Sold card: §a" + Util.fmt(Bank.bal(p.getUUID())) + " §7• pariu max " + Util.fmt(Cfg.I.maxBet))
            .in("bet", "Pariu (RON)", "100")
            .btn("Sloturi (3 la fel x10, 2 la fel x2)", "casino:slots")
            .btn("Ruletă - Roșu (x2)", "casino:roulette", "c", "red")
            .btn("Ruletă - Negru (x2)", "casino:roulette", "c", "black")
            .btn("Ruletă - Verde 0 (x14)", "casino:roulette", "c", "green")
            .send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        long bet = Util.num(d, "bet");
        if (s.equals("slotsmenu")) { menu(p); return; }
        if (bet < 1 || bet > Cfg.I.maxBet) { Util.msg(p, "§cPariu invalid (1-" + Cfg.I.maxBet + ")."); menu(p); return; }
        if (!Bank.take(u, bet, "Cazino: pariu")) { Util.msg(p, "§cFonduri insuficiente."); menu(p); return; }
        long win = 0;
        String res;
        if (s.equals("slots")) {
            int a = R.nextInt(SYM.length), b = R.nextInt(SYM.length), c = R.nextInt(SYM.length);
            res = "[" + SYM[a] + "][" + SYM[b] + "][" + SYM[c] + "]";
            if (a == b && b == c) win = bet * 10;
            else if (a == b || b == c || a == c) win = bet * 2;
        } else {
            int n = R.nextInt(37);
            String col = n == 0 ? "green" : (n % 2 == 1 ? "red" : "black");
            res = n + " " + col;
            String pick = Util.str(d, "c");
            if (pick.equals(col)) win = col.equals("green") ? bet * 14 : bet * 2;
        }
        if (win > 0) { Bank.add(u, win, "Cazino: câștig"); Util.msg(p, "§a" + res + " → ai câștigat " + Util.fmt(win)); }
        else Util.msg(p, "§c" + res + " → ai pierdut " + Util.fmt(bet));
        menu(p);
    }
}
