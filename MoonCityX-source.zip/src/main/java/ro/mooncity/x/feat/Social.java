package ro.mooncity.x.feat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** MoonNews (anunturi), reputatie si evenimente globale (multiplicator de plata). */
public class Social {
    static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("dd.MM HH:mm");

    public static void addRep(UUID u, int n) {
        CompoundTag r = Db.p(u);
        r.putInt("rep", r.getInt("rep") + n);
    }

    public static double payMult() {
        CompoundTag m = Db.sec("meta");
        return System.currentTimeMillis() < m.getLong("evtUntil") ? Math.max(0.1, m.getDouble("evtMult")) : 1.0;
    }

    public static void newsMenu(ServerPlayer p) {
        Ui u = Ui.of("§dMoonNews").line("§7Ultimele anunțuri din oraș:");
        ListTag l = Db.list(Db.sec("news"), "items");
        for (int i = l.size() - 1; i >= Math.max(0, l.size() - 12); i--) {
            CompoundTag c = l.getCompound(i);
            u.line("§8" + c.getString("at") + " §e" + c.getString("by") + "§f: " + c.getString("txt"));
        }
        if (l.isEmpty()) u.line("§8Niciun anunț încă.");
        u.sep().line("§7Postează un anunț (" + Util.fmt(Cfg.I.adPrice) + "):")
            .in("txt", "Text anunț", "").btn("Publică", "news:post");
        if (payMult() != 1.0) u.line("§6Eveniment activ: plăți x" + payMult());
        u.send(p);
    }

    public static void repMenu(ServerPlayer p) {
        Ui u = Ui.of("§6Reputație").line("§7Reputația ta: §f" + Db.p(p.getUUID()).getInt("rep"));
        List<Map.Entry<String, Integer>> top = new ArrayList<>();
        CompoundTag all = Db.sec("players");
        for (String k : all.getAllKeys()) top.add(Map.entry(all.getCompound(k).getString("name"), all.getCompound(k).getInt("rep")));
        top.sort((a, b) -> b.getValue() - a.getValue());
        u.sep().line("§eTop reputație:");
        for (int i = 0; i < Math.min(8, top.size()); i++) u.line("§f" + (i + 1) + ". " + top.get(i).getKey() + " §7- " + top.get(i).getValue());
        u.send(p);
    }

    public static void act(String m, ServerPlayer p, String s, CompoundTag d) {
        switch (m) {
            case "news" -> {
                if (s.equals("post")) {
                    String t = Util.str(d, "txt");
                    if (t.length() < 3) Util.msg(p, "§cText prea scurt.");
                    else if (!Bank.take(p.getUUID(), Cfg.I.adPrice, "Anunț MoonNews")) Util.msg(p, "§cFonduri insuficiente.");
                    else {
                        CompoundTag c = new CompoundTag();
                        c.putString("by", p.getName().getString());
                        c.putString("txt", t.length() > 120 ? t.substring(0, 120) : t);
                        c.putString("at", LocalDateTime.now().format(TS));
                        ListTag l = Db.list(Db.sec("news"), "items");
                        l.add(c);
                        while (l.size() > 40) l.remove(0);
                        Db.dirty();
                        City.budget(Cfg.I.adPrice, "Taxă anunț");
                    }
                }
                newsMenu(p);
            }
            case "rep" -> repMenu(p);
            case "evt" -> {
                if (!Util.op(p)) { Util.msg(p, "§cDoar adminii."); return; }
                if (s.equals("start")) {
                    CompoundTag meta = Db.sec("meta");
                    meta.putDouble("evtMult", Math.max(0.1, Util.num(d, "mult") / 100.0));
                    meta.putLong("evtUntil", System.currentTimeMillis() + Math.max(1, Util.num(d, "min")) * 60000L);
                    Db.dirty();
                    for (ServerPlayer o : p.server.getPlayerList().getPlayers()) Util.msg(o, "§6[Eveniment] Plăți x" + payMult() + "!");
                }
                evtMenu(p);
            }
            default -> newsMenu(p);
        }
    }

    static void evtMenu(ServerPlayer p) {
        Ui.of("§6Evenimente (admin)").in("mult", "Multiplicator plată în % (ex 150)", "150").in("min", "Durată minute", "30")
            .btn("Pornește eveniment", "evt:start").send(p);
    }
}
