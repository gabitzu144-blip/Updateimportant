package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import ro.mooncity.x.*;
import ro.mooncity.x.block.ShelfBE;

import java.util.*;

/** Magazine: nucleu de management (computer, tasta K), rafturi, stoc, preturi, finante, personal, vanzare magazin. */
public class Shops {
    static CompoundTag all() { return Db.sec("shops"); }

    static String nm(String id) {
        Item it = Util.item(id);
        return it == null ? id : new ItemStack(it).getHoverName().getString();
    }

    static CompoundTag rec(ServerLevel l, BlockPos p, boolean create) {
        String k = Util.posKey(l, p);
        CompoundTag a = all();
        if (!a.contains(k, Tag.TAG_COMPOUND)) {
            if (!create) return null;
            CompoundTag r = new CompoundTag();
            r.putString("owner", "");
            r.putString("name", "Magazin " + p.getX() + "," + p.getZ());
            r.putString("type", "general");
            r.putLong("value", 25000);
            r.putBoolean("sale", true);
            r.putLong("salePrice", 25000);
            r.putLong("bal", 0);
            a.put(k, r);
            Db.dirty();
        }
        return a.getCompound(k);
    }

    public static void removed(ServerLevel l, BlockPos p) {
        all().remove(Util.posKey(l, p));
        Db.dirty();
    }

    static boolean staff(CompoundTag r, UUID u) {
        if (r.getString("owner").equals(u.toString())) return true;
        ListTag s = r.getList("staff", Tag.TAG_STRING);
        for (int i = 0; i < s.size(); i++) if (s.getString(i).equals(u.toString())) return true;
        return false;
    }

    static boolean system(CompoundTag r) { return r.getString("owner").equals("SYSTEM"); }

    static void deliveries(CompoundTag r) {
        ListTag q = Db.list(r, "deliv");
        CompoundTag st = Db.sub(r, "stock");
        long now = System.currentTimeMillis();
        for (int i = q.size() - 1; i >= 0; i--) {
            CompoundTag d = q.getCompound(i);
            if (d.getLong("at") <= now) { st.putInt(d.getString("item"), st.getInt(d.getString("item")) + d.getInt("n")); q.remove(i); }
        }
    }

    static long base(String id) { return Cfg.I.shopBase.getOrDefault(id, 10); }

    static long priceOf(CompoundTag r, String id) {
        CompoundTag pr = Db.sub(r, "prices");
        return pr.contains(id) ? pr.getLong(id) : base(id);
    }

    // ------------------- click pe nucleu -------------------
    public static void act(ServerPlayer p, String s, CompoundTag d) {
        ServerLevel l = p.serverLevel();
        BlockPos pos = d.contains("pos") ? BlockPos.of(d.getLong("pos")) : null;
        UUID u = p.getUUID();
        if (s.equals("k")) { // tasta K: cel mai apropiat magazin al tau
            String best = null;
            double bd = 100;
            CompoundTag a = all();
            for (String k : a.getAllKeys()) {
                String[] x = k.split("\\|");
                if (!x[0].equals(l.dimension().location().toString())) continue;
                String[] c = x[1].split(",");
                double dd = p.distanceToSqr(Integer.parseInt(c[0]) + .5, Integer.parseInt(c[1]), Integer.parseInt(c[2]) + .5);
                if (dd < bd && (staff(a.getCompound(k), u) || Util.op(p))) { bd = dd; best = k; }
            }
            if (best == null) { Util.bar(p, "§cNu ești lângă niciun magazin al tău (10 blocuri)."); return; }
            String[] c = best.split("\\|")[1].split(",");
            mgmt(p, new BlockPos(Integer.parseInt(c[0]), Integer.parseInt(c[1]), Integer.parseInt(c[2])));
            return;
        }
        if (pos == null) return;
        CompoundTag r = rec(l, pos, true);
        deliveries(r);
        boolean st = staff(r, u) || Util.op(p);
        switch (s) {
            case "core" -> { if (r.getBoolean("sale") && !st) saleMenu(p, pos, r); else if (st) mgmt(p, pos); else info(p, pos, r); }
            case "buy" -> {
                long pr = r.getLong("salePrice");
                String target = r.getString("saleTo");
                if (!r.getBoolean("sale")) { Util.msg(p, "§cNu mai este de vânzare."); }
                else if (!target.isEmpty() && !target.equals(u.toString())) { Util.msg(p, "§cEste rezervat altui cumpărător."); }
                else if (!Bank.take(u, pr, "Cumpărare magazin " + r.getString("name"))) { Util.msg(p, "§cFonduri insuficiente."); }
                else {
                    String old = r.getString("owner");
                    if (!old.isEmpty() && !old.equals("SYSTEM")) Bank.add(UUID.fromString(old), pr, "Vânzare magazin " + r.getString("name"));
                    r.putString("owner", u.toString());
                    r.putBoolean("sale", false);
                    r.putString("saleTo", "");
                    r.put("staff", new ListTag());
                    Util.msg(p, "§aAi cumpărat magazinul! Apasă K lângă el sau click pe computer.");
                    Db.dirty();
                    mgmt(p, pos);
                    return;
                }
                saleMenu(p, pos, r);
            }
            case "m" -> { if (st) mgmt(p, pos); }
            default -> { if (st) manage(p, s, pos, r, d); }
        }
        Db.dirty();
    }

    static void saleMenu(ServerPlayer p, BlockPos pos, CompoundTag r) {
        CompoundTag d = new CompoundTag();
        d.putLong("pos", pos.asLong());
        Ui.of("§6" + r.getString("name") + " — de vânzare")
            .line("§7Tip: §f" + r.getString("type"))
            .line("§7Preț: §a" + Util.fmt(r.getLong("salePrice")))
            .line("§7Sold tău: §f" + Util.fmt(Bank.bal(p.getUUID())))
            .btn("Cumpără magazinul", "shop:buy", d).send(p);
    }

    static void info(ServerPlayer p, BlockPos pos, CompoundTag r) {
        Ui u = Ui.of("§6" + r.getString("name")).line("§7Proprietar: §f" + (system(r) ? "Statul" : Db.name(UUID.fromString(r.getString("owner")))));
        CompoundTag st = Db.sub(r, "stock");
        u.line("§7Produse (cumpără de pe rafturi cu click dreapta):");
        for (String k : st.getAllKeys()) if (st.getInt(k) > 0) u.line("§f" + nm(k) + " §7x" + st.getInt(k) + " §a" + priceOf(r, k) + " RON");
        u.send(p);
    }

    // ------------------- management -------------------
    static void mgmt(ServerPlayer p, BlockPos pos) {
        CompoundTag r = rec(p.serverLevel(), pos, true);
        deliveries(r);
        CompoundTag d = new CompoundTag();
        d.putLong("pos", pos.asLong());
        int items = 0;
        CompoundTag st = Db.sub(r, "stock");
        for (String k : st.getAllKeys()) items += st.getInt(k);
        Ui u = Ui.of("§9" + r.getString("name") + " — Management")
            .line("§7Proprietar: §f" + (system(r) ? "Statul" : r.getString("owner").isEmpty() ? "nimeni" : Db.name(UUID.fromString(r.getString("owner")))))
            .line("§7Balanță magazin: §a" + Util.fmt(r.getLong("bal")) + "  §7Valoare: §f" + Util.fmt(r.getLong("value")))
            .line("§7Stoc total: §f" + items + " buc.  §7Tip: §f" + r.getString("type"));
        u.btn("Prețuri", "shop:prices", d).btn("Aprovizionare", "shop:restock", d).btn("Finanțe", "shop:fin", d)
            .btn("Istoric vânzări", "shop:hist", d).btn("Personal", "shop:staff", d).btn("Vinde magazinul", "shop:sellm", d).send(p);
    }

    static void manage(ServerPlayer p, String s, BlockPos pos, CompoundTag r, CompoundTag d) {
        UUID u = p.getUUID();
        boolean owner = r.getString("owner").equals(u.toString()) || Util.op(p);
        CompoundTag pd = new CompoundTag();
        pd.putLong("pos", pos.asLong());
        CompoundTag st = Db.sub(r, "stock");
        switch (s) {
            case "prices" -> {
                int page = d.getInt("pg");
                List<String> ids = new ArrayList<>(new TreeSet<>(Cfg.I.shopBase.keySet()));
                for (String k : st.getAllKeys()) if (!ids.contains(k)) ids.add(k);
                Ui ui = Ui.of("§9Prețuri (min 60% / max 160% din baza)");
                int from = page * 8, to = Math.min(ids.size(), from + 8);
                for (int i = from; i < to; i++) {
                    String id = ids.get(i);
                    ui.line("§f" + nm(id) + " §7stoc " + st.getInt(id) + " • bază " + base(id));
                    ui.in("p" + i, "Preț", String.valueOf(priceOf(r, id)));
                }
                CompoundTag sv = pd.copy();
                sv.putInt("pg", page);
                ui.btn("Salvează prețurile", "shop:saveprices", sv);
                if (page > 0) { CompoundTag q = pd.copy(); q.putInt("pg", page - 1); ui.btn("« Pagina anterioară", "shop:prices", q); }
                if (to < ids.size()) { CompoundTag q = pd.copy(); q.putInt("pg", page + 1); ui.btn("Pagina următoare »", "shop:prices", q); }
                ui.btn("« Management", "shop:m", pd).send(p);
                return;
            }
            case "saveprices" -> {
                int page = d.getInt("pg");
                List<String> ids = new ArrayList<>(new TreeSet<>(Cfg.I.shopBase.keySet()));
                for (String k : st.getAllKeys()) if (!ids.contains(k)) ids.add(k);
                CompoundTag pr = Db.sub(r, "prices");
                for (int i = page * 8; i < Math.min(ids.size(), page * 8 + 8); i++) {
                    if (!d.contains("p" + i)) continue;
                    long v = Util.num(d, "p" + i);
                    long b = base(ids.get(i));
                    pr.putLong(ids.get(i), Math.max(Math.round(b * 0.6), Math.min(Math.round(b * 1.6), v)));
                }
                Util.msg(p, "§aPrețuri salvate (limitate între 60% și 160% din prețul de bază).");
                CompoundTag q = pd.copy();
                q.putInt("pg", page);
                manage(p, "prices", pos, r, q);
                return;
            }
            case "restock" -> {
                Ui ui = Ui.of("§9Aprovizionare (angro 55%) – livrare în 30 s").line("§7Balanță magazin: §a" + Util.fmt(r.getLong("bal")));
                for (String id : new TreeSet<>(Cfg.I.shopBase.keySet())) {
                    long w = Math.round(base(id) * 0.55);
                    CompoundTag a = pd.copy(); a.putString("i", id); a.putInt("n", 16);
                    CompoundTag b = pd.copy(); b.putString("i", id); b.putInt("n", 64);
                    ui.line("§f" + nm(id) + " §7angro " + w + " RON");
                    ui.btn("+16", "shop:order", a).btn("+64", "shop:order", b);
                }
                ListTag q = Db.list(r, "deliv");
                for (int i = 0; i < q.size(); i++) ui.line("§eÎn livrare: " + nm(q.getCompound(i).getString("item")) + " x" + q.getCompound(i).getInt("n"));
                ui.btn("Depozitează din inventarul meu", "shop:stash", pd).btn("« Management", "shop:m", pd).send(p);
                return;
            }
            case "order" -> {
                String id = Util.str(d, "i");
                int n = (int) Util.num(d, "n");
                if (!Cfg.I.shopBase.containsKey(id) || n <= 0 || n > 64) return;
                if ((id.endsWith("medkit") || id.endsWith("bandage")) && !Jobs.is(u, "medic")) { Util.msg(p, "§cDoar medicii pot comanda material medical."); }
                else {
                    long cost = Math.round(base(id) * 0.55) * n;
                    if (r.getLong("bal") < cost) Util.msg(p, "§cBalanța magazinului nu acoperă " + Util.fmt(cost));
                    else {
                        r.putLong("bal", r.getLong("bal") - cost);
                        CompoundTag dv = new CompoundTag();
                        dv.putString("item", id);
                        dv.putInt("n", n);
                        dv.putLong("at", System.currentTimeMillis() + 30_000);
                        Db.list(r, "deliv").add(dv);
                        hist(r, "-" + Util.fmt(cost) + " comandă " + n + "x " + nm(id));
                        Util.bar(p, "§aComandă plasată: " + n + "x " + nm(id));
                    }
                }
                manage(p, "restock", pos, r, pd);
                return;
            }
            case "stash" -> {
                int moved = 0;
                for (String id : Cfg.I.shopBase.keySet()) {
                    int c = Util.remove(p, id, Util.count(p, id));
                    if (c > 0) { st.putInt(id, st.getInt(id) + c); moved += c; }
                }
                Util.msg(p, "§aAi depozitat " + moved + " obiecte în stocul magazinului.");
                manage(p, "restock", pos, r, pd);
                return;
            }
            case "fin" -> {
                Ui ui = Ui.of("§9Finanțe").line("§7Balanță magazin: §a" + Util.fmt(r.getLong("bal"))).in("amt", "Suma", "1000");
                ui.btn("Retrage în contul meu", "shop:wd", pd).btn("Depune din contul meu", "shop:dep", pd).btn("Retrage tot", "shop:wdall", pd).btn("« Management", "shop:m", pd).send(p);
                return;
            }
            case "wd", "wdall" -> {
                if (!owner) { Util.msg(p, "§cDoar proprietarul."); }
                else {
                    long a = s.equals("wdall") ? r.getLong("bal") : Util.num(d, "amt");
                    if (a > 0 && a <= r.getLong("bal")) { r.putLong("bal", r.getLong("bal") - a); Bank.add(u, a, "Retragere din " + r.getString("name")); }
                }
                manage(p, "fin", pos, r, pd);
                return;
            }
            case "dep" -> {
                long a = Util.num(d, "amt");
                if (a > 0 && Bank.take(u, a, "Depunere în " + r.getString("name"))) { r.putLong("bal", r.getLong("bal") + a); }
                manage(p, "fin", pos, r, pd);
                return;
            }
            case "hist" -> {
                Ui ui = Ui.of("§9Istoric");
                ListTag h = r.getList("hist", Tag.TAG_STRING);
                for (int i = h.size() - 1; i >= 0 && i >= h.size() - 25; i--) ui.line("§f" + h.getString(i));
                ui.btn("« Management", "shop:m", pd).send(p);
                return;
            }
            case "staff" -> {
                Ui ui = Ui.of("§9Personal").line("§7Angajații pot seta rafturile și prețurile.");
                ListTag sl = Db.slist(r, "staff");
                for (int i = 0; i < sl.size(); i++) ui.line("§f" + Db.name(UUID.fromString(sl.getString(i))) + " §7(ID " + Db.id(UUID.fromString(sl.getString(i))) + ")");
                if (owner) ui.in("who", "Adaugă/șterge (ID/nume)", "").btn("Adaugă", "shop:sadd", pd).btn("Șterge", "shop:sdel", pd);
                ui.btn("« Management", "shop:m", pd).send(p);
                return;
            }
            case "sadd", "sdel" -> {
                UUID t = Db.find(Util.str(d, "who"));
                if (owner && t != null) {
                    ListTag sl = Db.slist(r, "staff");
                    for (int i = sl.size() - 1; i >= 0; i--) if (sl.getString(i).equals(t.toString())) sl.remove(i);
                    if (s.equals("sadd")) sl.add(net.minecraft.nbt.StringTag.valueOf(t.toString()));
                }
                manage(p, "staff", pos, r, pd);
                return;
            }
            case "sellm" -> {
                Ui ui = Ui.of("§9Vinde magazinul").line("§7Valoare: §f" + Util.fmt(r.getLong("value")))
                    .in("price", "Preț cerut", String.valueOf(r.getLong("value"))).in("to", "Doar pentru (ID/nume, opțional)", "")
                    .btn("Pune la vânzare (jucători)", "shop:sellp", pd).btn("Vinde statului (60%)", "shop:sells", pd).btn("« Management", "shop:m", pd);
                ui.send(p);
                return;
            }
            case "sellp" -> {
                if (owner) {
                    r.putBoolean("sale", true);
                    r.putLong("salePrice", Math.max(1, Util.num(d, "price")));
                    UUID t = Db.find(Util.str(d, "to"));
                    r.putString("saleTo", t == null ? "" : t.toString());
                    Util.msg(p, "§aMagazin pus la vânzare. Cumpărătorul dă click pe computer.");
                }
                mgmt(p, pos);
                return;
            }
            case "sells" -> {
                if (owner && !system(r)) {
                    long v = Math.round(r.getLong("value") * 0.6) + r.getLong("bal");
                    Bank.add(u, v, "Vânzare magazin către stat");
                    r.putString("owner", "");
                    r.putLong("bal", 0);
                    r.putBoolean("sale", true);
                    r.putLong("salePrice", r.getLong("value"));
                    Util.msg(p, "§aAi vândut magazinul statului pentru " + Util.fmt(v));
                }
                return;
            }
            default -> { }
        }
    }

    static void hist(CompoundTag r, String line) {
        Db.addStr(Db.slist(r, "hist"), java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd.MM HH:mm")) + "  " + line, 80);
    }

    // ------------------- rafturi -------------------
    public static void shelfUse(ServerPlayer p, ShelfBE be, BlockPos pos, InteractionHand h) {
        ServerLevel l = p.serverLevel();
        // cel mai apropiat nucleu de magazin in 24 blocuri
        CompoundTag a = all();
        String best = null;
        double bd = 24 * 24;
        for (String k : a.getAllKeys()) {
            String[] x = k.split("\\|");
            if (!x[0].equals(l.dimension().location().toString())) continue;
            String[] c = x[1].split(",");
            double dd = pos.distSqr(new BlockPos(Integer.parseInt(c[0]), Integer.parseInt(c[1]), Integer.parseInt(c[2])));
            if (dd < bd) { bd = dd; best = k; }
        }
        ItemStack hand = p.getItemInHand(h);
        if (best == null) {
            if (Util.op(p) && !hand.isEmpty()) { be.setShown(hand); Util.bar(p, "§aProdus afișat (raft fără magazin)."); }
            else Util.bar(p, "§cRaft fără magazin – pune un Computer de magazin la maxim 24 de blocuri.");
            return;
        }
        CompoundTag r = a.getCompound(best);
        deliveries(r);
        boolean st = staff(r, p.getUUID()) || Util.op(p);
        if (st && !hand.isEmpty() && !(hand.getItem() instanceof net.minecraft.world.item.BlockItem && Util.key(hand.getItem()).startsWith("mooncityx:shelf"))) {
            be.setShown(hand);
            Util.bar(p, "§aRaft setat: " + hand.getHoverName().getString() + " (preț " + priceOf(r, Util.key(hand.getItem())) + " RON)");
            return;
        }
        if (be.shown.isEmpty()) { Util.bar(p, "§7Raft gol."); return; }
        if (r.getBoolean("sale") && r.getString("owner").isEmpty()) { Util.bar(p, "§eMagazin fără proprietar."); return; }
        String id = Util.key(be.shown.getItem());
        CompoundTag stock = Db.sub(r, "stock");
        long price = priceOf(r, id);
        int qty = p.isShiftKeyDown() ? 8 : 1;
        if (!system(r)) qty = Math.min(qty, stock.getInt(id));
        if (qty <= 0) { Util.bar(p, "§cStoc epuizat: " + nm(id)); return; }
        long total = price * qty;
        if (!Bank.pay(p, total, "Cumpărare " + qty + "x " + nm(id) + " @ " + r.getString("name"))) { Util.bar(p, "§cNu ai " + Util.fmt(total) + " (numerar sau card)."); return; }
        long vat = Math.round(total * Cfg.I.vat / (1 + Cfg.I.vat));
        City.budget(vat, "TVA " + r.getString("name"));
        r.putLong("bal", r.getLong("bal") + total - vat);
        if (!system(r)) stock.putInt(id, stock.getInt(id) - qty);
        hist(r, "+" + Util.fmt(total) + " " + qty + "x " + nm(id) + " (" + p.getName().getString() + ")");
        ItemStack out = new ItemStack(be.shown.getItem(), qty);
        Util.give(p, out);
        Util.bar(p, "§a-" + Util.fmt(total) + " §7(" + qty + "x " + nm(id) + ", din care TVA " + Util.fmt(vat) + ")");
        String own = r.getString("owner");
        if (!own.isEmpty() && !own.equals("SYSTEM")) Social.addRep(UUID.fromString(own), 1);
        Db.dirty();
    }

    // ------------------- director de magazine (tab "Magazin" din inventar) -------------------
    public static void directory(ServerPlayer p) {
        Ui u = Ui.of("§6Magazine din oraș");
        CompoundTag a = all();
        int n = 0;
        for (String k : a.getAllKeys()) {
            CompoundTag r = a.getCompound(k);
            String o = r.getString("owner");
            String c = k.split("\\|")[1];
            if (o.isEmpty() || r.getBoolean("sale")) u.line("§a[DE VÂNZARE] §f" + r.getString("name") + " §7@ " + c + " • " + Util.fmt(r.getLong("salePrice")));
            else u.line("§f" + r.getString("name") + " §7(" + r.getString("type") + ") @ " + c + " • " + (o.equals("SYSTEM") ? "Stat" : Db.name(UUID.fromString(o))));
            if (++n >= 40) break;
        }
        if (n == 0) u.line("§7Niciun magazin încă. Adminii pun Computer de magazin din creative.");
        u.send(p);
    }

    public static void admin(ServerPlayer p, String sub, String arg) {
        // cel mai apropiat nucleu in 6 blocuri
        ServerLevel l = p.serverLevel();
        CompoundTag a = all();
        for (String k : a.getAllKeys()) {
            String[] x = k.split("\\|");
            if (!x[0].equals(l.dimension().location().toString())) continue;
            String[] c = x[1].split(",");
            if (p.distanceToSqr(Integer.parseInt(c[0]) + .5, Integer.parseInt(c[1]), Integer.parseInt(c[2]) + .5) > 36) continue;
            CompoundTag r = a.getCompound(k);
            switch (sub) {
                case "system" -> { r.putString("owner", "SYSTEM"); r.putBoolean("sale", false); }
                case "price" -> { r.putLong("value", Long.parseLong(arg)); r.putLong("salePrice", Long.parseLong(arg)); }
                case "type" -> r.putString("type", arg);
                case "name" -> r.putString("name", arg);
                case "reset" -> { r.putString("owner", ""); r.putBoolean("sale", true); }
                default -> { }
            }
            Db.dirty();
            Util.msg(p, "§aMagazin actualizat: " + r.getString("name"));
            return;
        }
        Util.msg(p, "§cNu ești lângă un computer de magazin (6 blocuri).");
    }
}
