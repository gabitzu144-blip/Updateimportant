package ro.mooncity.x.feat;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import ro.mooncity.x.*;

import java.time.LocalDate;
import java.util.*;

/** Contracte: legale (livrari, drumuri) si de pe piata neagra (mai bine platite, risc de "wanted"). */
public class Contracts {
    record Offer(String title, int kind, String item, int count, int x, int z, long reward, boolean ill, int pub) { }

    static final Object[][] LEGAL = {
        {"minecraft:wheat", 64, 380L}, {"minecraft:iron_ingot", 32, 1100L}, {"minecraft:oak_log", 128, 700L},
        {"minecraft:cooked_beef", 32, 1000L}, {"minecraft:coal", 64, 700L}, {"minecraft:bread", 48, 800L}, {"minecraft:diamond", 4, 1900L}
    };
    static final Object[][] ILL = {
        {"minecraft:gunpowder", 32, 3200L}, {"minecraft:gold_ingot", 24, 2600L}, {"minecraft:ender_pearl", 8, 3500L},
        {"minecraft:emerald", 8, 3000L}, {"minecraft:blaze_rod", 16, 3300L}
    };

    static List<Offer> offers(ServerPlayer p, boolean ill) {
        Random r = new Random(Db.id(p.getUUID()) * 31L + LocalDate.now().toEpochDay() * 7 + (ill ? 1 : 0));
        List<Offer> l = new ArrayList<>();
        Object[][] pool = ill ? ILL : LEGAL;
        BlockPos sp = p.serverLevel().getSharedSpawnPos();
        for (int i = 0; i < 5; i++) {
            if (i % 2 == 0) {
                Object[] o = pool[r.nextInt(pool.length)];
                var it = Util.item((String) o[0]);
                String nm = it == null ? (String) o[0] : new net.minecraft.world.item.ItemStack(it).getHoverName().getString();
                l.add(new Offer((ill ? "Livrare discretă: " : "Livrare: ") + o[1] + "x " + nm, 0, (String) o[0], (Integer) o[1], 0, 0, (Long) o[2], ill, -1));
            } else {
                double a = r.nextDouble() * Math.PI * 2, dist = 150 + r.nextInt(250);
                int x = sp.getX() + (int) (Math.cos(a) * dist), z = sp.getZ() + (int) (Math.sin(a) * dist);
                l.add(new Offer((ill ? "Transport riscant la " : "Mergi la ") + x + ", " + z, 1, "", 0, x, z, Math.round(dist * (ill ? 12 : 5)), ill, -1));
            }
        }
        if (!ill) { // contracte publice postate de primar
            ListTag pub = Db.list(Db.sec("city"), "pub");
            for (int i = 0; i < pub.size(); i++) {
                CompoundTag c = pub.getCompound(i);
                l.add(new Offer("[PUBLIC] " + c.getString("title"), 0, c.getString("item"), c.getInt("count"), 0, 0, c.getLong("reward"), false, i));
            }
        }
        return l;
    }

    public static void black(ServerPlayer p) { menu(p, true); }

    public static void menu(ServerPlayer p, boolean ill) {
        CompoundTag r = Db.p(p.getUUID());
        Ui u = Ui.of(ill ? "§8Piața neagră – contracte" : "§aContracte de livrare");
        List<Offer> o = offers(p, ill);
        u.line("§eOferte de azi (se schimbă zilnic):");
        for (int i = 0; i < o.size(); i++) {
            Offer f = o.get(i);
            CompoundTag d = new CompoundTag();
            d.putInt("i", i);
            d.putBoolean("ill", ill);
            u.btn(f.title() + " §a" + Util.fmt(f.reward()), "ctr:acc", d);
        }
        ListTag act = Db.list(r, "ctr");
        u.sep().line("§eContractele tale active (max 3):");
        for (int i = 0; i < act.size(); i++) {
            CompoundTag c = act.getCompound(i);
            CompoundTag d = new CompoundTag();
            d.putInt("i", i);
            d.putBoolean("ill", ill);
            u.line("§f" + c.getString("title") + " §a" + Util.fmt(c.getLong("reward")));
            if (c.getInt("kind") == 0) u.btn("Predă marfa", "ctr:done", d);
            u.btn("Anulează", "ctr:cancel", d);
        }
        if (ill) {
            u.sep().line("§7Marfă la negru (doar numerar fizic):");
            u.btn("Cheie falsă (lockpick) 800 RON", "ctr:buy", "k", "lock");
        }
        u.send(p);
    }

    public static void act(ServerPlayer p, String s, CompoundTag d) {
        UUID u = p.getUUID();
        CompoundTag r = Db.p(u);
        boolean ill = d.getBoolean("ill");
        switch (s) {
            case "menu" -> { }
            case "acc" -> {
                ListTag act = Db.list(r, "ctr");
                List<Offer> o = offers(p, ill);
                int i = d.getInt("i");
                if (act.size() >= 3) Util.msg(p, "§cAi deja 3 contracte active.");
                else if (i >= 0 && i < o.size()) {
                    Offer f = o.get(i);
                    CompoundTag c = new CompoundTag();
                    c.putString("title", f.title());
                    c.putInt("kind", f.kind());
                    c.putString("item", f.item());
                    c.putInt("count", f.count());
                    c.putInt("x", f.x());
                    c.putInt("z", f.z());
                    long rew = f.reward();
                    if (Jobs.is(u, "delivery")) rew = Math.round(rew * 1.25);
                    c.putLong("reward", rew);
                    c.putBoolean("ill", f.ill());
                    act.add(c);
                    if (f.pub() >= 0) {
                        ListTag pub = Db.list(Db.sec("city"), "pub");
                        if (f.pub() < pub.size()) pub.remove(f.pub());
                    }
                    Util.msg(p, "§aContract acceptat: " + f.title());
                }
            }
            case "done" -> {
                ListTag act = Db.list(r, "ctr");
                int i = d.getInt("i");
                if (i >= 0 && i < act.size()) {
                    CompoundTag c = act.getCompound(i);
                    if (Util.count(p, c.getString("item")) < c.getInt("count")) Util.msg(p, "§cNu ai marfa necesară.");
                    else { Util.remove(p, c.getString("item"), c.getInt("count")); complete(p, c); act.remove(i); }
                }
            }
            case "cancel" -> {
                ListTag act = Db.list(r, "ctr");
                int i = d.getInt("i");
                if (i >= 0 && i < act.size()) act.remove(i);
            }
            case "buy" -> {
                if (Bank.takeCash(p, 800)) { Util.give(p, new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.TRIPWIRE_HOOK)
                    .setHoverName(net.minecraft.network.chat.Component.literal("§8Cheie falsă"))); }
                else Util.msg(p, "§cAici se plătește doar cu numerar (800 RON).");
            }
            default -> { }
        }
        Db.dirty();
        menu(p, ill);
    }

    static void complete(ServerPlayer p, CompoundTag c) {
        long rew = c.getLong("reward");
        boolean ill = c.getBoolean("ill");
        if (ill) { Bank.giveCash(p, rew); Util.msg(p, "§8Ai primit " + Util.fmt(rew) + " în numerar murdar."); if (new Random().nextInt(100) < 30) Mdt.setWanted(p.getUUID(), true, "Activitate suspectă (piața neagră)"); }
        else { long tax = Math.round(rew * Cfg.I.incomeTax); City.budget(tax, "Impozit contracte"); Bank.add(p.getUUID(), rew - tax, "Contract: " + c.getString("title")); Util.msg(p, "§aContract finalizat! +" + Util.fmt(rew - tax)); }
        Social.addRep(p.getUUID(), 2);
    }

    /** Apelat din tick (la 20 tick-uri) pentru contracte de tip "mergi la". */
    public static void tick(ServerPlayer p) {
        CompoundTag r = Db.p(p.getUUID());
        if (!r.contains("ctr", Tag.TAG_LIST)) return;
        ListTag act = r.getList("ctr", Tag.TAG_COMPOUND);
        for (int i = act.size() - 1; i >= 0; i--) {
            CompoundTag c = act.getCompound(i);
            if (c.getInt("kind") != 1) continue;
            double dx = p.getX() - c.getInt("x"), dz = p.getZ() - c.getInt("z");
            if (dx * dx + dz * dz < 64) { complete(p, c); act.remove(i); Db.dirty(); }
        }
    }
}
