package ro.mooncity.x.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import ro.mooncity.x.Cfg;
import ro.mooncity.x.MoonNpc;
import ro.mooncity.x.MoonX;
import ro.mooncity.x.Net;
import ro.mooncity.x.Reg;

public class ClientSetup {
    public static final KeyMapping OPEN = new KeyMapping("key.mooncityx.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.mooncityx");

    @Mod.EventBusSubscriber(modid = MoonX.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(Reg.NPC.get(), ctx -> new HumanoidMobRenderer<MoonNpc, HumanoidModel<MoonNpc>>(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f) {
                @Override public ResourceLocation getTextureLocation(MoonNpc n) { return new ResourceLocation("textures/entity/player/wide/steve.png"); }
            });
        }

        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) { e.register(OPEN); }

        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("hud", (gui, g, pt, w, h) -> {
                if (ClientHooks.hud != 0 || ClientHooks.id == 0) return;
                var f = Minecraft.getInstance().font;
                g.drawString(f, "§bID §f" + ClientHooks.id + "  §7" + ClientHooks.job, w - 150, 6, 0xFFFFFF);
                g.drawString(f, "§aBancă §f" + ClientHooks.bank + " RON", w - 150, 16, 0xFFFFFF);
                g.drawString(f, "§eNumerar §f" + ClientHooks.cash + " RON", w - 150, 26, 0xFFFFFF);
            });
        }
    }

    @Mod.EventBusSubscriber(modid = MoonX.ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void key(net.minecraftforge.client.event.InputEvent.Key e) {
            if (OPEN.consumeClick() && Minecraft.getInstance().screen == null && Minecraft.getInstance().player != null)
                Net.toServer("phone:open", new CompoundTag());
        }

        /** Ascunde HUD-urile configurate (ex. vitezometrul vechi din mooncityvehicles). */
        @SubscribeEvent
        public static void overlay(RenderGuiOverlayEvent.Pre e) {
            if (Cfg.I.hiddenOverlays.contains(e.getOverlay().id().toString())) e.setCanceled(true);
        }
    }
}
