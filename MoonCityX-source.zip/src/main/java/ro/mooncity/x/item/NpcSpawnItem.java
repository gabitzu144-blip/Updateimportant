package ro.mooncity.x.item;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import ro.mooncity.x.MoonNpc;
import ro.mooncity.x.Reg;

/** Pui un NPC cu rolul respectiv (doar admin/creative). */
public class NpcSpawnItem extends Item {
    final String role;

    public NpcSpawnItem(String role) {
        super(new Item.Properties().stacksTo(16));
        this.role = role;
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        if (c.getLevel() instanceof ServerLevel sl && c.getPlayer() instanceof ServerPlayer sp) {
            if (!sp.hasPermissions(2) && !sp.isCreative()) {
                sp.displayClientMessage(Component.literal("§cDoar adminii pot pune NPC-uri."), true);
                return InteractionResult.FAIL;
            }
            BlockPos p = c.getClickedPos().relative(c.getClickedFace());
            MoonNpc n = new MoonNpc(Reg.NPC.get(), sl);
            n.moveTo(p.getX() + .5, p.getY(), p.getZ() + .5, sp.getYRot() + 180f, 0f);
            n.setRole(role);
            sl.addFreshEntity(n);
            if (!sp.isCreative()) c.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(c.getLevel().isClientSide);
    }
}
