package ro.mooncity.x.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import ro.mooncity.x.Net;

public class PhoneItem extends Item {
    public PhoneItem() { super(new Item.Properties().stacksTo(1)); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level l, Player pl, InteractionHand h) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) Net.to(sp, "phone", new CompoundTag());
        return InteractionResultHolder.sidedSuccess(pl.getItemInHand(h), l.isClientSide);
    }
}
