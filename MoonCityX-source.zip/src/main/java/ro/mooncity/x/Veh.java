package ro.mooncity.x;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/** Pod catre MrCrayfish Vehicle prin reflexie (nu avem nevoie de el la compilare). */
public class Veh {
    static final Map<String, Method> CACHE = new HashMap<>();
    static final String POWERED = "com.mrcrayfish.vehicle.entity.PoweredVehicleEntity";

    public static boolean powered(Entity e) {
        for (Class<?> c = e.getClass(); c != null; c = c.getSuperclass()) if (c.getName().equals(POWERED)) return true;
        return false;
    }

    static Object call(Object o, String n, Class<?>[] sig, Object... a) {
        try {
            String k = o.getClass().getName() + "#" + n + sig.length;
            Method m = CACHE.get(k);
            if (m == null) { m = o.getClass().getMethod(n, sig); CACHE.put(k, m); }
            return m.invoke(o, a);
        } catch (Throwable t) {
            return null;
        }
    }

    static Object call(Object o, String n) { return call(o, n, new Class<?>[0]); }

    static float f(Object o, String n) { Object r = call(o, n); return r instanceof Number x ? x.floatValue() : 0f; }

    static void setF(Object o, String n, float v) { call(o, n, new Class<?>[]{float.class}, v); }

    public static float fuelOf(net.minecraft.nbt.CompoundTag n) { return n.contains("CurrentFuel") ? n.getFloat("CurrentFuel") : 0f; }
    public static float fuel(Entity e) { return f(e, "getCurrentFuel"); }
    public static float cap(Entity e) { return f(e, "getFuelCapacity"); }
    public static void setFuel(Entity e, float v) { setF(e, "setCurrentFuel", v); }
    public static float maxSpeed(Entity e) { return f(e, "getMaxSpeed"); }
    public static void setMaxSpeed(Entity e, float v) { setF(e, "setMaxSpeed", v); }
    public static float accel(Entity e) { return f(e, "getAccelerationSpeed"); }
    public static void setAccel(Entity e, float v) { setF(e, "setAccelerationSpeed", v); }
    public static double kmh(Entity e) { Object r = call(e, "getKilometersPreHour"); return r instanceof Number x ? x.doubleValue() : 0; }
    public static ItemStack engine(Entity e) { Object r = call(e, "getEngineStack"); return r instanceof ItemStack s ? s : ItemStack.EMPTY; }
    public static void setEngine(Entity e, ItemStack s) { call(e, "setEngineStack", new Class<?>[]{ItemStack.class}, s); }
    public static ItemStack wheel(Entity e) { Object r = call(e, "getWheelStack"); return r instanceof ItemStack s ? s : ItemStack.EMPTY; }
    public static void setWheel(Entity e, ItemStack s) { call(e, "setWheelStack", new Class<?>[]{ItemStack.class}, s); }
    public static boolean canWheels(Entity e) { return Boolean.TRUE.equals(call(e, "canChangeWheels")); }
    public static boolean canColor(Entity e) { return Boolean.TRUE.equals(call(e, "canBeColored")); }
    public static int color(Entity e) { Object r = call(e, "getColor"); return r instanceof Number x ? x.intValue() : 0xFFFFFF; }
    public static void setColor(Entity e, int c) { call(e, "setColor", new Class<?>[]{int.class}, c); }

    /** Aplica viteza/acceleratia configurate + treapta tuning (stage). Sigur de apelat des (nu se cumuleaza). */
    public static void applySpeed(Entity e) {
        if (!powered(e)) return;
        var d = e.getPersistentData();
        if (!d.contains("moon_base")) {
            d.putFloat("moon_base", maxSpeed(e));
            d.putFloat("moon_abase", accel(e));
        }
        int stage = d.getInt("moon_stage");
        float base = d.getFloat("moon_base");
        float ab = d.getFloat("moon_abase");
        if (base <= 0) return;
        float mult = Cfg.I.speedMultiplier * (1f + 0.12f * stage);
        float amult = Cfg.I.accelMultiplier * (1f + 0.10f * stage);
        if (Math.abs(maxSpeed(e) - base * mult) > 0.001f) setMaxSpeed(e, base * mult);
        if (ab > 0 && Math.abs(accel(e) - ab * amult) > 0.001f) setAccel(e, ab * amult);
    }
}
