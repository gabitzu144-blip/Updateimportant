package ro.mooncity.x;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;

/** Constructor de meniuri trimise clientului (un singur ecran generic le afiseaza pe toate). */
public class Ui {
    final CompoundTag t = new CompoundTag();
    final ListTag items = new ListTag();

    public static Ui of(String title) {
        Ui u = new Ui();
        u.t.putString("title", title);
        return u;
    }

    public Ui line(String s) {
        CompoundTag c = new CompoundTag();
        c.putString("t", "l");
        c.putString("s", s);
        items.add(c);
        return this;
    }

    public Ui sep() { return line(""); }

    public Ui btn(String label, String act) { return btn(label, act, new CompoundTag()); }

    public Ui btn(String label, String act, String k, String v) {
        CompoundTag d = new CompoundTag();
        d.putString(k, v);
        return btn(label, act, d);
    }

    public Ui btn(String label, String act, String k, long v) { return btn(label, act, k, Long.toString(v)); }

    public Ui btn(String label, String act, CompoundTag d) {
        CompoundTag c = new CompoundTag();
        c.putString("t", "b");
        c.putString("s", label);
        c.putString("a", act);
        c.put("d", d);
        items.add(c);
        return this;
    }

    public Ui in(String key, String label, String def) {
        CompoundTag c = new CompoundTag();
        c.putString("t", "i");
        c.putString("k", key);
        c.putString("s", label);
        c.putString("v", def);
        items.add(c);
        return this;
    }

    public void send(ServerPlayer p) {
        t.put("items", items);
        Net.to(p, "menu", t);
    }
}
